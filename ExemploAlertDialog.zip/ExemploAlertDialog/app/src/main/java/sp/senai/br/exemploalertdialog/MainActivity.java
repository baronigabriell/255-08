package sp.senai.br.exemploalertdialog;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    //classe responsável pela criação do ALertDialog
    AlertDialog alerta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }
    public void exemplo1 (View e){
        //instanciar o alert e gerá-lo
        AlertDialog.Builder criaAlerta = new AlertDialog.Builder(this);
        //define um título para a janela
        criaAlerta.setTitle("Exemplo 1");
        //define a mensagem
        criaAlerta.setMessage("Primeiro exemplo de AlertDialog");
        //criar um alert dialog com as definições acima
        alerta = criaAlerta.create();
        //exibe o alerta
        alerta.show();
    }
    public void exemplo2 (View e){
        //instanciar o alert e gerá-lo
        AlertDialog.Builder criaAlerta = new AlertDialog.Builder(this);
        //define um título para a janela
        criaAlerta.setTitle("Exemplo 2");
        //define a mensagem
        criaAlerta.setMessage("Escolha uma opção:");
        //define os botões de ação
        //SetPositive realiza uma ação desejada ou afirmativa, tipo OK, Salvar, Sim....
        criaAlerta.setPositiveButton("Positivo", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "Clicou no Positivo", Toast.LENGTH_LONG).show();
            }
        });
        //SetNegative realiza uma ação anulada ou cancelada, tipo Cancelar, Fechar, Não....
        criaAlerta.setNegativeButton("Negativo", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, "Clicou no Negativo", Toast.LENGTH_LONG).show();
            }
        });
        //criar um alert dialog com as definições acima
        alerta = criaAlerta.create();
        //exibe o alerta
        alerta.show();

    }
    public void exemplo3 (View e){
        //instanciar o alert e gerá-lo
        AlertDialog.Builder criaAlerta = new AlertDialog.Builder(this);
        //define um título para a janela
        criaAlerta.setTitle("Exemplo 3");
        //LayoutInflater é utilizado para "inflar" (inserir) um novo layout dentro de uma view (no caso será o AlertDialog)
        //pegamos a instancia da classe
        LayoutInflater li = getLayoutInflater();
        //inflamos o alerta.xml nesta view
        View visual = li.inflate(R.layout.alerta, null);
        //criamos a ação do botão
        visual.findViewById(R.id.btnSair).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //fecha o dialogo
                alerta.dismiss();
            }
        });
        //atribuir a view ao alertdialog
        criaAlerta.setView(visual);
        //criar um alert dialog com as definições acima
        alerta = criaAlerta.create();
        //exibe o alerta
        alerta.show();
    }
}